let shopingCart = document.querySelector('shoping-cart');
document.querySelector('#cart-btn').onclick = () => {
    shopingCart.classList.toggle('active');
}